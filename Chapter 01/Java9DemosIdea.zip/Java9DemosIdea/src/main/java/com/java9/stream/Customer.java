//Listing 1-5
package com.java9.stream;

public class Customer implements Comparable<Customer>{
	int customerId;
	String customerName;
	double customerBalance;
	
	
	@Override
	public String toString() {
		return customerId +" , "+customerName+" , "+customerBalance;
	}


	public Customer(int customerId, String customerName, double customerBalance) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerBalance = customerBalance;
	}


	public int getCustomerId() {
		return customerId;
	}


	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}


	public String getCustomerName() {
		return customerName;
	}


	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public double getCustomerBalance() {
		return customerBalance;
	}


	public void setCustomerBalance(double customerBalance) {
		this.customerBalance = customerBalance;
	}


	@Override
	public int compareTo(Customer customer) {
		// TODO Auto-generated method stub
		return this.customerBalance > customer.customerBalance ? 1 : this.customerBalance < customer.customerBalance ? -1 : 0;
	}
	
}

