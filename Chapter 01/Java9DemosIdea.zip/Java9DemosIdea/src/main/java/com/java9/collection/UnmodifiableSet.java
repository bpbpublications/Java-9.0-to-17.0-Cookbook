//Listing 1-10
package com.java9.collection;

import java.util.Set;

public class UnmodifiableSet {
	public static void main(String[] args)
	{
		//creating empty Set
		Set<Employee> empSet1=Set.of();
		
		//creating Set with one object
		Set<Employee> empSet2=Set.of(new Employee(101,"William Smith"));
		
		//creating Set with multiple objects, can accept upto 10 elements
		Set<Employee> empSet3=Set.of(new Employee(101,"William Smith"),
										new Employee(102,"Rakesh Ahuja"),
										new Employee(103,"David Monte"));
		
		System.out.println("Printing empty Set ==>");
		empSet1.forEach(e->System.out.println(e));
	
		System.out.println("Printing set with 1 element ==>");
		empSet2.forEach(e->System.out.println(e));
		
		System.out.println("Printing set with mutiple(upt0 10) elements ==>");
		empSet3.forEach(e->System.out.println(e));
	}
}
