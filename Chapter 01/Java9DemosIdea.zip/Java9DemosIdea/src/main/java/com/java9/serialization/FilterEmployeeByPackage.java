//Listing 1-21
package com.java9.serialization;

import java.io.ObjectInputFilter;

public class FilterEmployeeByPackage {
    static ObjectInputFilter.Status empFilter(ObjectInputFilter.FilterInfo filterInfo) {
    	//Generating the class type which object is being serialized
        Class<?> serialClass = filterInfo.serialClass();
        if (serialClass != null) {
        	//checking if the deserialized object is part of specific package
        	return serialClass.getPackageName().equals("java.util")
                    ? ObjectInputFilter.Status.ALLOWED
                    : ObjectInputFilter.Status.REJECTED;
        }
        return ObjectInputFilter.Status.UNDECIDED;
    }
}

