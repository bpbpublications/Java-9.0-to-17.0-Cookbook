//Listing 1-7
package com.java9.stream;

import java.util.stream.Stream;

public class IterateDemo {
	public static void main(String[] args) {

		// iterate() without Predicate : Java 8
		System.out.println("Java 8 style : iterate() without Predicate: ==>");
		Stream.iterate(101, i -> i + 1).limit(10)
				.forEach(number->System.out.print(number+" "));

		// iterate() with Predicate : Java 9
		System.out.println("\nJava 9 style : iterate() with Predicate: ==>");
		Stream.iterate(101, i -> i <= 110, i -> i + 1) 
				.forEach(number->System.out.print(number+" "));

	}
}
