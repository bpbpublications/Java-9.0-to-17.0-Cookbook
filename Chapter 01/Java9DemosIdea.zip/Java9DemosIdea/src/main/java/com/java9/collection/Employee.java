//Listing 1-8
package com.java9.collection;

class Employee{
	int empId;
	String name;
	public Employee(int empId, String name) {
		super();
		this.empId = empId;
		this.name = name;
	}
	
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", name=" + name + "]";
	}
	
}
