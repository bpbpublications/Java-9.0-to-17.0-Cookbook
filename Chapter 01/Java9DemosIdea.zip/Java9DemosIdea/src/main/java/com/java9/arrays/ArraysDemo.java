//Listing 1-12
package com.java9.arrays;

import java.util.Arrays;

public class ArraysDemo {
	public static void main(String[] args) {
		int[] data1 = {10,20,30,40,50};
        int[] data2 = {10,20,30,40,50};
        int[] data3 = {8,20,30,40};
        
        checkArray(data1,data2,data3);
	}
	
	public static void checkArray(int[] data1, int[] data2, int[] data3) {

		//Demonstration of equals()
        System.out.println("\nArrays.equals(data1, 0, 3, data3, 0, 3): " +
                Arrays.equals(data1, 0, 3, data3, 0, 3));
        System.out.println("Arrays.equals(data1, 0, 3, data2, 0, 3): " +
        		Arrays.equals(data1, 0, 3, data2, 0, 3));
        
        //Demonstration of compare()
        System.out.println("data1 and data2 comparison := "+
        						Arrays.compare(data1, data2));
        System.out.println("data1 and data3 comparison := "+
        						Arrays.compare(data1, data3));
        //Demonstration of mismatch()
        System.out.println("data1 and data2 comparison by mismatch:= "+
        						Arrays.mismatch(data1, data2));
        System.out.println("data1 and data3 comparison by mismatch:= "+
        						Arrays.mismatch(data1, data3));
	}

}
