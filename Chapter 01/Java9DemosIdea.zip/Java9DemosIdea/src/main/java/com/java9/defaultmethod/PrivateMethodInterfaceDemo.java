//Listing 1-2
package com.java9.defaultmethod;

public class PrivateMethodInterfaceDemo implements PrivateMethodInterface{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PrivateMethodInterfaceDemo demo=new PrivateMethodInterfaceDemo();
		demo.method1();
		demo.method2();
	}
}
