//Listing 1-24
package com.java9.flowapi;

import java.util.concurrent.Flow;
import java.util.concurrent.Flow.Subscription;

public class BookSubscriber implements Flow.Subscriber<Book>{
	private String subscriberName;
	private Flow.Subscription subscription;
	
	public BookSubscriber(String subscriberName) {
		this.subscriberName=subscriberName;
	}
	  
	@Override
	public void onSubscribe(Subscription subscription) {
		// TODO Auto-generated method stub
		this.subscription=subscription;
		subscription.request(1);
	}

	@Override
	public void onNext(Book book) {
		// TODO Auto-generated method stub
		subscription.request(1);
		System.out.println(book +" ,Received by : "+this.subscriberName);
	}

	@Override
	public void onError(Throwable throwable) {
		// TODO Auto-generated method stub
		System.out.println(throwable.getMessage());
	}

	@Override
	public void onComplete() {
		// TODO Auto-generated method stub
		System.out.println(subscriberName +" got all the books");
	}

}
