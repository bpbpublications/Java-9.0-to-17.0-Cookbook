//Listing 1-11
package com.java9.collection;

import java.util.Map;
import static java.util.Map.entry;

public class UnmodifiableMap {
	public static void main(String[] args) {
		//creating empty Set
		Map<Integer, Employee> empMap1=Map.of();
				
		//creating Set with one object
		Map<Integer,Employee> empMap2=Map.of(1, new Employee(101,"William Smith"));
				
		//creating Set with multiple objects, can accept upto 10 elements
		Map<Integer, Employee> empMap3=Map.of(1,new Employee(101,"William Smith"),
											2,new Employee(102,"Rakesh Ahuja"),
											3,new Employee(103,"David Monte"));
				
		//creating arbitrary number of elements in Map 
		Map<Integer,Employee> empMap4=Map.ofEntries(
							entry(1, new Employee(101,"William Smith")),
							entry(2, new Employee(102, "Rakesh Ahuja")),
							entry(3, new Employee(103, "David Monte"))
							);		
		
		System.out.println("Printing empty Map ==>");
		empMap1.forEach((k,v)->System.out.println("key="+k+", value=" +v));
		
		System.out.println("Printing map of one element ==>");
		empMap2.forEach((k,v)->System.out.println("key="+k+", value=" +v));
		
		System.out.println("Printing map of multiple(upto 10) elements ==>");
		empMap3.forEach((k,v)->System.out.println("key="+k+", value=" +v));
		
		System.out.println("Using Map.ofEntries ==>");
		empMap4.forEach((k,v)->System.out.println("key="+k+", value=" +v));
		
	}

}
