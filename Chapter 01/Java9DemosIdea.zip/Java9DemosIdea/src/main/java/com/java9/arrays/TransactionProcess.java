//Listing 1-15
package com.java9.arrays;

import java.util.Arrays;

public class TransactionProcess {
	public static void main(String[] args) {
		Transaction transaction1=new Transaction("txn1",10000);
		Transaction transaction2=new Transaction("txn2",20000);
		Transaction transaction3=new Transaction("txn3",30000);
		Transaction transaction4=new Transaction("txn4",40000);
		
		Transaction transaction5=new Transaction("txn1",10000);
		Transaction transaction6=new Transaction("txn2",20000);
		Transaction transaction7=new Transaction("txn5",30000);
		Transaction transaction8=new Transaction("txn4",40000);
		
		checkTransaction(new Transaction[] {transaction1,transaction2,transaction3,transaction4},
						 new Transaction[] {transaction5,transaction6,transaction7,transaction8});
		
	}

	private static void checkTransaction(Transaction[] transactions1, Transaction[] transactions2) {
		// TODO Auto-generated method stub
		int x=Arrays.mismatch(transactions1, transactions2, new TransactionComparator());
		if(x==-1)
			System.out.println("Arrays are matched");
		System.out.println("First "+x+" elements are matched");
	}
}
