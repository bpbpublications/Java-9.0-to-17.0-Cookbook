//Listing 1-22
package com.java9.serialization;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class FilteringDeserialization {
	public static void main(String[] args) throws IOException {
		filteringByClass();
		filteringByMethod();
	}

	// filtering the de-serialization by invoking the filter class
	private static void filteringByClass() throws IOException {
		// TODO Auto-generated method stub
		FileInputStream is = new FileInputStream("emp.dat");
		try (ObjectInputStream ois = new ObjectInputStream(is)) {
			ois.setObjectInputFilter(new FilterEmployee());
			Employee employee = (Employee) ois.readObject();
			
			System.out.println("Employee object after applying filter:"+'\n'+employee);
		} catch (ClassNotFoundException ex) {
			System.out.println("Cannot deserialize");
		}
	}
	
	// filtering the de-serialization by invoking the method
	private static void filteringByMethod() throws IOException {
		// TODO Auto-generated method stub
		FileInputStream is = new FileInputStream("emp.dat");
		try (ObjectInputStream ois = new ObjectInputStream(is)) {
			ois.setObjectInputFilter(FilterEmployeeByPackage::empFilter);
			Employee employee = (Employee) ois.readObject();
			
			System.out.println("Employee object after applying filter:"+'\n'+employee);
			System.out.println(employee);
		} catch (ClassNotFoundException ex) {
			System.out.println("Cannot deserialize");
		}
	}
}
