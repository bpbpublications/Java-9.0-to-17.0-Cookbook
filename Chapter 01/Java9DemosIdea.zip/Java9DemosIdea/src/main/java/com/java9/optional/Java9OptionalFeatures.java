//Listing 1-17
package com.java9.optional;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;
import java.util.stream.Collectors;

public class Java9OptionalFeatures {
  static List<Employee> employeeList
        = Arrays.asList(new Employee("Bob Wiliams", 45, 15000.00),
          new Employee("Johny Hiscus", 45, 7000.00),
          new Employee("Alan Marsh", 65, 8000.00),
          new Employee("Jack Tavolta", 22, 10000.00),
          new Employee("Brayan Waugh", 29, 9000.00));
 
  public static void main(String[] args) {
    
	  Optional<Employee> maxSalaryEmp = 
            employeeList.stream()
            .filter(e->e.getSalary()>20000)
            .findFirst();
    
    /* Java 8 way to find the object conditionally 
    if(maxSalaryEmp.isPresent())
    	System.out.println(maxSalaryEmp.toString());
    System.out.println("Condition is not matched");
   */
    
    //working with ifPresentOrElse() in Optional
    System.out.print("Checking availablity of object using ifPresentOrEsle() ---> ");
    maxSalaryEmp.ifPresentOrElse((e)->System.out.println(e.toString()), ()->System.out.println(" Employee not found"));
    
    //Creation of Supplier to supply the default object 
    Supplier<Optional<Employee>> supplierEmployee = () -> Optional.of(new Employee("Tom Jones", 45, 7000.00));
    
    //working with or() in Optional
    System.out.println("Supplying the default object if object not found --->");
    maxSalaryEmp=maxSalaryEmp.or(supplierEmployee);
    Employee e=maxSalaryEmp.get();
    System.out.println(e);
    
    //Creation of list consisting non-null and null objects 
    List<Optional<Employee>> list = Arrays.asList(
            Optional.empty(),Optional.of(new Employee("Mark Root", 25, 7000.00)),
            		Optional.of(new Employee("Daniel Martin", 35, 17000.00)   ));
    
    /*Java 8 way to create list of non-null objects using isPresent()
    List<Employee> filteredListJava8 = list.stream()
            .flatMap(o -> o.isPresent() ? Stream.of(o.get()) : Stream.empty())
            .collect(Collectors.toList());
    */
    
    // Java 9 way to create list of non-null objects using Optional::stream.
     List<Employee> filteredListJava9 = list.stream()
            .flatMap(Optional::stream)
            .collect(Collectors.toList());
     
     System.out.print("List of non-null Employees --->");
     System.out.println(filteredListJava9);
  }
}