//Listing 1-20
package com.java9.serialization;

import java.io.ObjectInputFilter;

class FilterEmployee implements ObjectInputFilter{
    public Status checkInput(FilterInfo filterInfo) {
    	//Generating the class type which object is being serialized
        Class<?> serialClass = filterInfo.serialClass();
        if (serialClass != null) {
        	return (Employee.class.isAssignableFrom(serialClass)) ? Status.ALLOWED : Status.REJECTED;
        }
        else {
        	System.out.println("NULL");
        return Status.UNDECIDED;
        }
    }
}    
