//Listing 1-25
package com.java9.flowapi;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.SubmissionPublisher;
import java.util.concurrent.TimeUnit;

public class BookPublisher {
	public static void main(String[] args) {
		List<Book> bookList = Arrays.asList(
				new Book[] { 
						new Book(101, "Java 9 to 13"), 
						new Book(102, "Java 11") 
						});

		SubmissionPublisher<Book> bookPublisher = 
				new SubmissionPublisher<Book>();

		BookSubscriber subscriber1 = new BookSubscriber("Dave");
		BookSubscriber subsrciber2 = new BookSubscriber("Richardson");
		bookPublisher.subscribe(subscriber1);
		bookPublisher.subscribe(subsrciber2);

		// submit() method:
		System.out.println("Using submit() method :==>");
		bookList.stream().forEach(i -> {
			bookPublisher.submit(i);
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});

		// offer() method : simple form
		System.out.println("Using offer() :==>");
		bookList.stream().forEach(book -> {
			bookPublisher.offer(book, null);
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});

		// offer() method : timeout implementation
		System.out.println("Using offer() with timeout :==>");
		bookList.stream().forEach((book) -> {
			System.out.println(book + " being offered");
			final int result1 = bookPublisher.offer(book, 2, TimeUnit.SECONDS, 
					(subscriber, value) -> {
						try {
								Thread.sleep(3000);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						return true;
			});
			if (result1 < 2)
				System.out.println("Dropping " + result1 + " book.");
		});
	
	}
}
