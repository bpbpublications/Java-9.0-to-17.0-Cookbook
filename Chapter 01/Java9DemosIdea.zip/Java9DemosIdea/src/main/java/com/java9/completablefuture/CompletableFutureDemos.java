package com.java9.completablefuture;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

public class CompletableFutureDemos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		completeOnTime();
		orTimeOut();
		delayedExecutor();
		
	}

	//implementation of completeOnTime()
	private static void completeOnTime() {
		// TODO Auto-generated method stub
		int value1 = 100;
		int value2 = 200;

		CompletableFuture.supplyAsync(() -> {
			try {
				TimeUnit.SECONDS.sleep(5);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			return value1 + value2;
		}).completeOnTimeout(10, 2, TimeUnit.SECONDS).
					thenAccept(result -> System.out.println("Result from completeOnTime()==> "+result));
		//waits for 2 seconds to complete, else returns 10 as a value
		try {
			TimeUnit.SECONDS.sleep(10);//waiting for 10 seconds
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//implementaion of orTimeOut()
	//sets a time limit of 1 seconds else returns exception
	private static void orTimeOut() {
		// TODO Auto-generated method stub
		int value1 = 100;
		int value2 = 200;

		CompletableFuture.supplyAsync(() -> {
			try {
				TimeUnit.SECONDS.sleep(3);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			return value1 + value2;
		}).orTimeout(1, TimeUnit.SECONDS).whenComplete((result, exception) -> {
			System.out.println("Result from orTimeOut()==> "+result);
			if (exception != null) {
				exception.printStackTrace();
				System.out.println("Job not completed on Time");
			}
		});

		try {
			TimeUnit.SECONDS.sleep(10); //waiting for 10 seconds
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	//implementation of delayedExecutor()
	private static void delayedExecutor() {
		// TODO Auto-generated method stub
		int value1 = 100;
		int value2 = 200;

		CompletableFuture.supplyAsync(() -> value1 + value2, 
				CompletableFuture.delayedExecutor(2, TimeUnit.SECONDS))
				.thenAccept(result -> System.out.println("Result from delayedExecutor()==> "+result));

		try {
			TimeUnit.SECONDS.sleep(10);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
