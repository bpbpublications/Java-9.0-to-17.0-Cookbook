//Listing 1-18
package com.java9.serialization;

import java.io.Serializable;

public class Employee implements Serializable {
	int empId;
	String empName;
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + "]";
	}
	public Employee(int empId, String empName) {
		super();
		this.empId = empId;
		this.empName = empName;
	}
	

}
