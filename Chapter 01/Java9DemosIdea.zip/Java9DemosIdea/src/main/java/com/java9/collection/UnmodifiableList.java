//Listing 1-9
package com.java9.collection;

import java.util.List;

public class UnmodifiableList {
	public static void main(String[] args)
	{
		//creating empty List
		List<Employee> empList1=List.of();
		
		//creating List with one object
		List<Employee> empList2=List.of(new Employee(101,"William Smith"));
		
		//creating list with multiple objects, can accept upto 10 elements
		List<Employee> empList3=List.of(new Employee(101,"William Smith"),
										new Employee(102,"Rakesh Ahuja"),
										new Employee(103,"David Monte"));
		System.out.println("Printing empty list:==>");
		empList1.forEach((e)->System.out.println(e));
		
		System.out.println(("Printing list of 1 element ==>"));
		empList2.forEach((e)->System.out.println(e));
		
		System.out.println("Printing list of multiple elements (upto 10)==>");
		empList3.forEach((e)->System.out.println(e));
		
	}

}
