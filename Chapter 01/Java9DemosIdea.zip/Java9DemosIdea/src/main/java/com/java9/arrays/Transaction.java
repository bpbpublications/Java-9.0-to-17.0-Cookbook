//Listing 1-13
package com.java9.arrays;

public class Transaction {
	private String transactionId;
	private double transactionAmount;
	
	public Transaction(String transactionId, double transactionAmount) {
		super();
		this.transactionId = transactionId;
		this.transactionAmount = transactionAmount;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public double getTransactionAmount() {
		return transactionAmount;
	}
	public void setTransactionAmount(double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	

}
