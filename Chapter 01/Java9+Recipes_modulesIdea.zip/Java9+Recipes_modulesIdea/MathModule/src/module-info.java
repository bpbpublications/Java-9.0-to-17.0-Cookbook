//Listing 1-27
module MathModule {
	
}