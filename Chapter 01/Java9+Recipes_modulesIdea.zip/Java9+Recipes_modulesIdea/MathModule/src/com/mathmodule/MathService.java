//Listing 1-28
package com.mathmodule;

import java.util.ArrayList;
import java.util.List;

public class MathService {
	
	public static List<Integer> 
		checkNumbers(List<Integer> numbers, int value){
		
		List<Integer> numberList=new ArrayList<Integer>();
		numbers.forEach((x)->{
			if(x % value==0)
				numberList.add(x);
		});
		return numberList;
	}

}
