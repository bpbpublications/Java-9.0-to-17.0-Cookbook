//Listing 1-29
package com.mathmodule;

import java.util.Arrays;
import java.util.List;

public class MathMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> generatedList=
				MathService.checkNumbers(Arrays.asList(10,20,35,40), 2);
		generatedList.forEach(System.out::println);
		}
}
